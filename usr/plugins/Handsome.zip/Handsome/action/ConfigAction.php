<?php

/**
 * 配置页面进行的一些action 操作
 * hewro 2020/02/21
 */

class ConfigAction{

}
