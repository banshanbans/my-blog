# cache 组件
`var/Typecho/Db.php`

目前typecho 支持的数据库类型有：
- mysql
  - mysqli  mysql 增强版本，能够兼容mysql语法
- sqlite
- pgsql

除此之外有一些变体，如pdo_pgsql，仍然driver类型属于pgsql：https://www.imooc.com/wenda/detail/590359