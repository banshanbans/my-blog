# plugin component

随着 Plugin.php 的代码量逐渐增加，已经到了需要拆分的地步，否则无法很好维护。因此将该文件拆分成多个单文件来进行维护。