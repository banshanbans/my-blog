<?php

class Handsome_Plugin_Config{
    public static function config(Typecho_Widget_Helper_Form &$form) {

    }
}
